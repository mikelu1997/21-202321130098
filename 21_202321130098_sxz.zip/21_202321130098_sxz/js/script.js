document.addEventListener('DOMContentLoaded', function() {
 
  console.log('网站加载完成');
  
 
});